# **Zemsta**



Akcja toczy się na zamku, który podzielony jest na dwie części murem. Jedna część należy do Cześnika Macieja Raptusiewicza, druga do Rejenta Milczka. Obaj żyją w ciągłym sporze. Nowa awantura wybucha, gdy Rejent najmuje mularzy do naprawienia muru granicznego, na co Cześnik pod żadnym razem się nie zgadza.





Treść zewnętrzna

Cześnik planuje ożenić się z Podstoliną, jako majętną wdówką i nakazuje Papkinowi, by przygotował mu pod to grunt. Wszystko się udaje i Podstolina zgadza się wyjść za Cześnika.



W ogrodowej altanie potajemnie spotyka się syn Rejenta – Wacław i Starościanka Klara. Łączy ich prawdziwa miłość, jednakże wiedzą, że ojciec młodzieńca i stryj dziewczyny nigdy nie zgodzą się na ich ślub. Wacław podstępem wkrada się do domu Cześnika, jako jeniec Papkina, przedstawiając się w roli Komisarza Rejenta. Cześnik nie chce go widzieć w swoim domu, jednak Wacław przekupuje Papkina, aby pomógł mu zostać i doprowadzić do ślubu z Klarą. Papkin z kolei zakochany jest w Klarze i to jej wyznaje miłość. Klara go zwodzi i prosi o dowody miłości.



Okazuje się, że Wacław zna Podstolinę z dawnych czasów, gdy pałali do siebie uczuciem. Teraz nie wie, jak się od niej uwolnić, nie zdradzając jednocześnie swej miłości do Klary.



Cześnik wymyśla, że w zemście za remont muru granicznego wyzwie Rejenta na pojedynek. Wysyła z tą wiadomością Papkina, który przy okazji staje się świadkiem podstępu Rejenta. Milczek przekonuje Podstolinę, by zostawiła Cześnika i poślubiła Wacława. Wprawdzie Wacław się na to nie zgadza, ale ojciec jest nieugięty. Papkin jest załamany sytuacją, ponieważ wie, że złość Cześnika będzie ogromna i wszystkim się za to dostanie. Rejent odsyła Papkina do Cześnika z listem, w którym podejmuje wyzwanie i jednocześnie informuje o planach ślubnych Podstoliny i Wacława.



Wściekły Cześnik po przeczytaniu wiadomości od Rejenta, wymyśla podstęp. Próbuje dyktować Dyndalskiemu list od Klary do Wacława, ale nic z tego nie widzi. W końcu posyła służącą, by zwabiła Wacława do domu Cześnika pod pozorem prośby o spotkanie Klary.



Wacław mówi Klarze o planach swego ojca. Papkin pisze testament, sądząc, że został otruty przez Rejenta i zdradza młodym niecne plany Cześnika. Wacław próbuje uciec, ale zostaje pojmany przez Cześnika, który na złość Rejentowi i Podstolinie chce zmusić Wacława do ślubu z Klarą, na co nieoczekiwanie dla Raptusiewicza, oboje od razu się zgadzają.



Wacław i Klara biorą ślub. Rejent przychodzi do Cześnika i dowiaduje się o ślubie. Cześnik jest zadowolony, że zrobił Rejentowi na złość. Rejent nie chce dać błogosławieństwa młodym. Gdy Podstolina dowiaduje się o ślubie, zdradza, że śpieszyło jej się do małżeństwa, ponieważ dziś jej majątek przechodzi na Klarę, ale za zerwaną umowę Rejent winien jej jest sto tysięcy. Klara bierze dług na siebie i prosi o błogosławieństwo, które młodzi wreszcie otrzymują. Cześnik wyciąga rękę na zgodę, Rejent ją przyjmuje.

